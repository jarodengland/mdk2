from gov.nasa.jpl.mbee.mdk.docgen.docbook import DBParagraph

scriptOutput = [DBParagraph("Hello World")]